


debug = False

debug_localization = False
debug_mapping = False
debug_pathplanning = False
debug_motionplanning = False

debug_live = False
debug_live_amount = 0
debug_map_live_amount = 0
debug_path_live_amount = 0

# [NEW]: Container to store destination_pt selected by User
destination = []