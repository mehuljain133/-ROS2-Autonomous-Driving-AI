# 🐳 ROS 2 SELF-DRIVING CAR — WINDOWS + WSL2 + DOCKER — ALLLLLLL MAXED

# ======================================================
# 🔹 PRE-REQUISITES INSTALLATION (WINDOWS)
# ======================================================

# 1️⃣ Install Docker Desktop
https://docs.docker.com/desktop/install/windows-install/

# 2️⃣ Enable / Upgrade to WSL-2
wsl --install
wsl --set-default-version 2

# 3️⃣ Install VcXsrv X Server (GUI Support)
https://sourceforge.net/projects/vcxsrv/

# Launch VcXsrv with:
# ✅ Multiple Windows
# ✅ Start no client
# ✅ Disable access control


# ======================================================
# 1️⃣ PULL ROS 2 SELF-DRIVING IMAGE
# ======================================================

docker pull noshluk2/ros2-self-driving-car-ai-using-opencv:latest


# ======================================================
# 2️⃣ CREATE CONTAINER FROM IMAGE
# ======================================================

# 🚀 CUDA GPU ENABLED (NVIDIA — FASTEST)
docker run -it \
  --name ros2_sdc_container \
  --runtime=nvidia \
  --gpus all \
  -e DISPLAY=host.docker.internal:0.0 \
  -e LIBGL_ALWAYS_INDIRECT=0 \
  -e ROS_DOMAIN_ID=0 \
  -e RMW_IMPLEMENTATION=rmw_fastrtps_cpp \
  --shm-size=4g \
  --privileged \
  noshluk2/ros2-self-driving-car-ai-using-opencv \
  bash


# 🐢 NON-CUDA (AMD / CPU — SLOWER)
docker run -it \
  --name ros2_sdc_container \
  -e DISPLAY=host.docker.internal:0.0 \
  -e LIBGL_ALWAYS_INDIRECT=0 \
  -e ROS_DOMAIN_ID=0 \
  --shm-size=2g \
  --privileged \
  noshluk2/ros2-self-driving-car-ai-using-opencv \
  bash


# ⚠️ IMPORTANT
# DO NOT run the above command multiple times.
# It will create MULTIPLE containers.
# ONLY ONE container is needed.


# ======================================================
# 3️⃣ START CONTAINER IF STOPPED
# ======================================================

docker start ros2_sdc_container


# ======================================================
# 4️⃣ ENTER RUNNING CONTAINER
# ======================================================

docker exec -it ros2_sdc_container bash


# ======================================================
# 5️⃣ LAUNCH ROS 2 SELF-DRIVING PROJECT
# ======================================================

# STEP 1 — Launch Prius Gazebo Environment
ros2 launch self_driving_car_pkg world_gazebo.launch.py


# STEP 2 — Open NEW terminal & reconnect container
docker exec -it ros2_sdc_container bash


# STEP 3 — Go to Project Workspace
cd ~/ROS2-Self-Driving-Car-AI-using-OpenCV/


# STEP 4 — Run Self-Driving Vision Node
ros2 run self_driving_car_pkg computer_vision_node


# ======================================================
# 🧠 BONUS — POWER COMMANDS
# ======================================================

# List containers
docker ps -a

# Stop container
docker stop ros2_sdc_container

# Restart container
docker restart ros2_sdc_container

# Remove container if needed
docker rm ros2_sdc_container

# Monitor GPU (CUDA users)
nvidia-smi

# Monitor Docker performance
docker stats
