#!/usr/bin/env bash

echo "🔥 Starting ROS 2 MAX DOCKER MODE..."

# ==============================
# X11 ACCESS (GUI ENABLED)
# ==============================
xhost +local:root

# ==============================
# XAUTH SETUP (SECURE DISPLAY)
# ==============================
XAUTH=/tmp/.docker.xauth
touch $XAUTH
xauth nlist $DISPLAY | sed -e 's/^..../ffff/' | xauth -f $XAUTH nmerge -

# ==============================
# GPU & NVIDIA OPTIMIZATION
# ==============================
export NVIDIA_VISIBLE_DEVICES=all
export NVIDIA_DRIVER_CAPABILITIES=all

# ==============================
# ROS ENVIRONMENT BOOST
# ==============================
ROS_DOMAIN_ID=0
RMW_IMPLEMENTATION=rmw_fastrtps_cpp

# ==============================
# DOCKER RUN (MAX PERFORMANCE)
# ==============================
docker run -it --rm \
    --name ros2_sdc_container \
    --hostname ros2_ai_machine \
    --shm-size=4g \
    --ipc=host \
    --pid=host \
    --ulimit memlock=-1 \
    --ulimit stack=67108864 \
    --privileged \
    --net=host \
    --runtime=nvidia \
    --gpus all \
    \
    # DISPLAY / GUI
    --env DISPLAY=$DISPLAY \
    --env QT_X11_NO_MITSHM=1 \
    --env XAUTHORITY=$XAUTH \
    --volume /tmp/.X11-unix:/tmp/.X11-unix:rw \
    --volume $XAUTH:$XAUTH \
    \
    # ROS ENV VARS
    --env ROS_DOMAIN_ID=$ROS_DOMAIN_ID \
    --env RMW_IMPLEMENTATION=$RMW_IMPLEMENTATION \
    \
    # GPU / CUDA
    --env NVIDIA_VISIBLE_DEVICES=all \
    --env NVIDIA_DRIVER_CAPABILITIES=compute,utility,graphics \
    \
    # PERFORMANCE CACHE
    --volume /dev:/dev \
    --volume /run:/run \
    \
    # WORKSPACE MOUNTS (DEV MODE)
    --volume $HOME/ros2_workspace:/root/ros2_workspace \
    --volume $HOME/extra_ros_ws:/root/extra_ros_ws \
    --volume $HOME/slam_ws:/root/slam_ws \
    \
    # CAMERA / USB / DEVICES
    --device /dev/video0:/dev/video0 \
    --device /dev/video1:/dev/video1 \
    \
    # AUDIO SUPPORT (OPTIONAL)
    --device /dev/snd \
    \
    # TIME SYNC
    --volume /etc/localtime:/etc/localtime:ro \
    \
    # IMAGE
    noshluk2/ros2-self-driving-car-ai-using-opencv \
    bash

echo "✅ ROS 2 Docker session finished."
