# 🐳 DOCKER COMMANDS — ROS / GPU / GUI — ALLLLLLL MAXED

### Learn Docker for ROS (Recommended)
https://www.youtube.com/watch?v=qWuudNxFGOQ

# ======================================================
# 📦 IMAGES — FULL CONTROL
# ======================================================

# Download image
docker pull <image_name>

# List all images
docker images -a

# Delete single image
docker rmi <image_id>

# Delete ALL images
docker rmi -f $(docker images -q)

# Delete dangling images
docker image prune -f

# Delete unused images, containers, cache (FULL CLEAN)
docker system prune -a

# Save image to file
docker save -o image.tar <image_name>

# Load image from file
docker load -i image.tar


# ======================================================
# 📦 CONTAINERS — MAX CONTROL
# ======================================================

# Create interactive container
docker run -it <image_name>

# Create container with name
docker run -it --name <container_name> <image_name>

# Create background container
docker run -dit --name <container_name> <image_name>

# List running containers
docker ps

# List ALL containers
docker ps -a

# Start stopped container
docker start <container_id_or_name>

# Stop running container
docker stop <container_id_or_name>

# Stop ALL containers
docker stop $(docker ps -q)

# Kill ALL containers (force)
docker kill $(docker ps -q)

# Enter running container shell
docker exec -it <container_id> bash

# Delete single container
docker rm <container_id_or_name>

# Delete ALL containers
docker rm -f $(docker ps -aq)

# View container logs
docker logs <container_id>

# Inspect container settings
docker inspect <container_id>

# Live resource stats
docker stats


# ======================================================
# 🏗️ BUILD IMAGE FROM DOCKERFILE (FIXED)
# ======================================================

# Build image from Dockerfile (RUN INSIDE DIRECTORY)
docker build -t <image_name> .

# ❌ Wrong: docker built
# ✅ Correct: docker build


# ======================================================
# 🖥️ GUI SUPPORT — WINDOWS (ROS / RVIZ / GAZEBO)
# ======================================================

docker run -it \
  --name ros2_gui_container \
  -e DISPLAY=host.docker.internal:0.0 \
  <image_name> \
  bash


# ======================================================
# 🖥️ GUI SUPPORT — LINUX (ROS / RVIZ / GAZEBO)
# ======================================================

xhost +local:docker

docker run -it \
  --env DISPLAY=$DISPLAY \
  --volume /tmp/.X11-unix:/tmp/.X11-unix \
  --net=host \
  <image_name> \
  bash


# ======================================================
# 🎮 GPU / NVIDIA MODE — AI / ROS / OPENCV / CUDA
# ======================================================

docker run -it \
  --gpus all \
  --runtime=nvidia \
  --privileged \
  <image_name> \
  bash


# ======================================================
# 🤖 ROS 2 MAX TEMPLATE — GUI + GPU + DEV
# ======================================================

docker run -it --rm \
  --name ros2_container \
  --hostname ros2_machine \
  --net=host \
  --privileged \
  --runtime=nvidia \
  --gpus all \
  --shm-size=4g \
  --ipc=host \
  -e DISPLAY=$DISPLAY \
  -e ROS_DOMAIN_ID=0 \
  -e RMW_IMPLEMENTATION=rmw_fastrtps_cpp \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  -v $HOME/ros2_workspace:/root/ros2_workspace \
  <image_name> \
  bash


# ======================================================
# 🧪 COMPLETE WINDOWS GUI EXAMPLE (FIXED)
# ======================================================

docker run -it \
  --name r2_pathplanning_container \
  -e DISPLAY=host.docker.internal:0.0 \
  haiderabbasi333/ros2-pathplanning-course:1 \
  bash


# ======================================================
# ⚠️ COMMON MISTAKES — FIXED
# ======================================================

# ❌ Wrong
docker run --name -it <container_name> <image_name>

# ✅ Correct
docker run -it --name <container_name> <image_name>
