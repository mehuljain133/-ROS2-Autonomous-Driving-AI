# 🐳 ROS 2 SELF-DRIVING CAR — DOCKER + NVIDIA — ALLLLLLL MAXED SETUP

# ======================================================
# 1️⃣ INSTALL DOCKER ON UBUNTU 22.04
# ======================================================

Official guide:
https://www.digitalocean.com/community/tutorials/how-to-install-and-use-docker-on-ubuntu-22-04

Quick install:
sudo apt update
sudo apt install -y docker.io
sudo systemctl enable --now docker
sudo usermod -aG docker $USER

# Log out & log back in after this


# ======================================================
# 2️⃣ INSTALL NVIDIA RUNTIME (GPU ACCELERATION)
# ======================================================
# Reference:
https://github.com/NVIDIA/nvidia-docker/issues/838

# Add NVIDIA GPG Key
curl -s -L https://nvidia.github.io/nvidia-docker/gpgkey | sudo apt-key add -

# Detect OS Distribution
distribution=$(. /etc/os-release;echo $ID$VERSION_ID)

# Add NVIDIA Docker Repo
curl -s -L https://nvidia.github.io/nvidia-docker/$distribution/nvidia-docker.list | sudo tee /etc/apt/sources.list.d/nvidia-docker.list

# Update Package List
sudo apt-get update

# Install NVIDIA Docker Runtime
sudo apt-get install -y nvidia-docker2

# Reload Docker Daemon
sudo pkill -SIGHUP dockerd

# Verify GPU Docker Works
docker run --rm --gpus all nvidia/cuda:11.8.0-base nvidia-smi


# ======================================================
# 3️⃣ PULL ROS 2 SELF-DRIVING IMAGE
# ======================================================

docker pull noshluk2/ros2-self-driving-car-ai-using-opencv:latest


# ======================================================
# 4️⃣ CREATE CONTAINER SCRIPT (GUI + GPU + ROS MAX)
# ======================================================

nano create_container.bash

# ---------------- COPY THIS SCRIPT -------------------

#!/usr/bin/env bash

echo "🚀 Starting ROS 2 Self-Driving Container..."

# Enable X11 GUI
xhost +local:root

# Secure XAUTH
XAUTH=/tmp/.docker.xauth
touch $XAUTH
xauth nlist $DISPLAY | sed -e 's/^..../ffff/' | xauth -f $XAUTH nmerge -

# Run container (MAX MODE)
docker run -it \
  --name ros2_sdc_container \
  --hostname ros2_ai_machine \
  --privileged \
  --net=host \
  --runtime=nvidia \
  --gpus all \
  --shm-size=4g \
  --ipc=host \
  --pid=host \
  \
  -e DISPLAY=$DISPLAY \
  -e QT_X11_NO_MITSHM=1 \
  -e XAUTHORITY=$XAUTH \
  -e ROS_DOMAIN_ID=0 \
  -e RMW_IMPLEMENTATION=rmw_fastrtps_cpp \
  \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  -v $XAUTH:$XAUTH \
  -v $HOME/ros2_workspace:/root/ros2_workspace \
  \
  --device /dev/video0 \
  --device /dev/video1 \
  --device /dev/snd \
  \
  noshluk2/ros2-self-driving-car-ai-using-opencv:latest \
  bash

echo "✅ Container exited."

# ---------------- END SCRIPT -------------------


# ======================================================
# 5️⃣ MAKE SCRIPT EXECUTABLE
# ======================================================

chmod +x create_container.bash


# ======================================================
# 6️⃣ RUN CONTAINER (ONLY ONCE!)
# ======================================================

./create_container.bash

# ⚠️ IMPORTANT:
# DO NOT run script repeatedly.
# It will create multiple containers.
# Only ONE container is required.


# ======================================================
# 7️⃣ START CONTAINER IF STOPPED
# ======================================================

docker start ros2_sdc_container


# ======================================================
# 8️⃣ ENTER RUNNING CONTAINER
# ======================================================

docker exec -it ros2_sdc_container bash


# ======================================================
# 9️⃣ LAUNCH SELF-DRIVING PROJECT
# ======================================================

# STEP 1 — Launch Gazebo World with Prius Car
ros2 launch self_driving_car_pkg world_gazebo.launch.py

# STEP 2 — Open new terminal & connect container
docker exec -it ros2_sdc_container bash

# STEP 3 — Go to project workspace
cd ~/ROS2-Self-Driving-Car-AI-using-OpenCV/

# STEP 4 — Run Self-Driving Node
ros2 run self_driving_car_pkg computer_vision_node


# ======================================================
# 🧠 BONUS POWER COMMANDS
# ======================================================

# List containers
docker ps -a

# Stop container
docker stop ros2_sdc_container

# Remove container (if needed)
docker rm ros2_sdc_container

# Monitor GPU inside container
nvidia-smi

# Monitor Docker performance
docker stats
